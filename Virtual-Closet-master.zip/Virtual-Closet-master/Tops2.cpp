#include <iostream>
#include <string>
#include <sqlite3.h>
#include <string>
#include <cstring>

using namespace std;

class Tops
{
public:
        char *shortSleeves[100];
        char *longSleeves[100];

/*class ShortSleeevs: public Tops
{
        struct shortSleeve
        {
                char VNeck[30];
                char CrewNeck[30];
                char TankTop[30];
                char BottomU[30];;
                shortSleeve *next;
        };
public:*/
        Tops();
        ~Tops();
        std::string getData();
	void save();	

        //void setVNeck(const char *);
        //void setCrewNeck(string);
        //void setTankTop(string);
        //void setBottomUp(string);

        //void getShirtType(string);

private:
        //shortSleeve *head;
};

class LongSleeves : public Tops
{
	LongSleeves();
	~LongSleeves();

	void getShirtType();

private:
	string VNeck;
	string CrewNeck;
	string BottomUp;
};

std::string Tops::getData()
{
 std::string shortSleeves;
 cout << "Please enter a short sleeve option\n";
 cin >> shortSleeves;

 return shortSleeves;
}

void Tops::save()
{
 std::string input = getData();
 sqlite3* db;
 sqlite3_open("test.db", &db);
 std::string sql = "CREATE TABLE Tops ( Tops_ID INT PRIMARY KEY, Type_VNeck char NOT NULL, Type_BottonUp char NOT NULL, Type_Tank char NOT NULL, Type_Crew char NOT NULL, Type_TurtleNeck NOT NULL, Type_Sweatshirts NOT NULL);";
 sqlite3_exec(db, sql.c_str(), NULL, 0, NULL);

 sql = "INSERT INTO Tops(Tops_ID, Type_VNeck) VALUES (1, \"" + input +" \");";

 sqlite3_exec(db, sql.c_str(), NULL, 0, NULL);

 sqlite3_close(db);
}

Tops:: Tops()
{

}

Tops:: ~Tops()
{
}

int main()
{
 Tops test;
 test.save();

 return 0;
}
