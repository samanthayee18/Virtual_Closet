# Virtual-Closet

Virtual Closet/Outfit Organizer/ Digital Closet


Motivation: The one thing our team members have in common is that we all wear clothes. Sometimes picking out the right outfit is a struggle. So, we wanted to make an easy way to pick out outfits for everyday use or for special occasions or conditions. This would make the daily task of putting clothes on easier and stress free.

Goals:
* Short-term: Enable user to input their clothes and outfits into a database. Be able to put it into categories. Once clothes are input, can generate outfit or make your own outfit. Be able to save a favorite outfit. Custom change generated outfit.
   * Categories:
      * Tops - short, long sleeves 
      * Bottom - shorts, pants, skirts, etc. 
      * Shoes
* Long-term: - weather specific outfits. Event specific outfits.Be able to check location and get weather then suggest outfit. 




Roles:
* Graphical Interface(Robert) 
* Data management(Daniel, Samantha)
* Application flow and communication(Caesar)
