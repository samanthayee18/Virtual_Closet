#include <iostream>
#include <sqlite3.h>
#include <string>
#include <cstring>
#include "db.h"
#include <vector>
using namespace std;


class shoes
{
public:
char* everyDay[100];
char* athletic[100];
char* fancy[100]; 

std::string ID;
std::string shoeType;
bool remembered;

std:: vector<shoes*> getData();
int callback(void*, std::string, std::string);
bool isRemembered();
void setRemembered(bool);
std::string getshoeType();

shoes();
shoes(std::string ID, std::string shoeType);
~shoes();

void save();

private:

};

std::string shoes::getshoeType()
{
char shoeType;
cout<<"a. Everyday\n";
cout<<"b. Athletic\n";
cout<<"c. Fancy\n";
cin>> shoeType;

switch(shoeType)
{
case 'a' : return "Everyday"; break;
case 'b' : return "Athletic"; break;
case 'c' : return "Fancy"; break;
}
}

void shoes::save()
{
std::string input = getshoeType();
sqlite3* db; //=DB::getConnections();
sqlite3_open("test.db",&db);
std::string sql="CREATE TABLE Shoes (Shoes_ID INT PRIMARY KEY, Type_Everyday char NOT NULL, Type_Athletic char NOT NULL, Type_Fancy);";
sqlite3_exec(db, sql.c_str(), NULL,0,NULL);

sql="INSERT INTO Shoes (Shoes_ID, Type_Everyday) VALUES (1,\""+input+"\");";

char* err;

sqlite3_exec(db, sql.c_str(), NULL, 0, &err);
if(err!=NULL)
{
cout<<err<<endl<<std::flush;
}

sqlite3_close(db);
}

shoes:: shoes(){}
shoes:: ~shoes(){}
shoes::shoes(std::string ID, std::string shoeType)

{
this->ID=ID;
this->shoeType=shoeType;
}

std::vector<shoes*> shoes::getData()

{
std::vector<shoes*>* shoe = new std::vector<shoes*>;
sqlite3* db;// DB::getConnection();
sqlite3_open("test.db", &db);
std::string sql="SELECT Shoes_ID, Type_Everyday From shoes";
char*err;
sqlite3_exec(db,sql.c_str(),0/*Shoes::callback*/, shoe, &err);
if(err!=NULL)
{
cout<<err<<endl<<std::flush;
}
sqlite3_close(db);
return *shoe;
}

int shoes::callback(void *data, std::string ID, std::string shoeType)
{
std::vector<shoes*>* shoe = (std::vector<shoes*>*)data;
shoes*b= new shoes(ID,shoeType);
b->setRemembered(true);
(*shoe).push_back(b);
return 0;
}

bool shoes::isRemembered()
{
return remembered;
}

void shoes::setRemembered(bool remembered)
{
this->remembered = remembered;
}

int main()
{

shoes test;
test.save();

return 0;
}
