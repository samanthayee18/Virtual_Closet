#ifndef VIRTUALCLOSET_H
#define VIRTUALCLOSET_H
#include "gui.h"
#include <map>


//Gallery Widget class to hold images 
//Used in cpp file to create new objects and create packed widgets
//Allows us to add widgets dynamically
class GalleryWidget : public Gtk::VBox {
	private:
		
		Gtk::HBox* img_container;
		Gtk::Image* image;
		Gallery* gallery;

	public: 
		GalleryWidget(Gallery*);
		std::string getImage();
		Gallery* getImage();
};

//GenerateOutfitWidget class to hold images 
//Used in cpp file to create new objects and create packed widgets
//Allows us to add widgets dynamically
class GenerateOutfitWidget : public Gtk::VBox {
	private:
		Gtk::HBox* outfit_container;
		Gtk::Image* image;
		GenerateOutfit* getImage();
};

//ViewControllers		
class LoginController: public ViewController {
	public: 
		LoginController(GladeAppManager*, std::string, bool);		
		
		bool clickClose(GdkEventAny*);
		void login();
		void loginSuccess();
};

class OptionsController: public ViewController {
	public:
		
		OptionsController(GladeAppManager*, std::string, bool);

		bool clickClose(GdkEventAny*);
		void insertclothes();
		void viewcloset();
		void genoutfit();
};

class InsertClothesController: public ViewController {
	public:
		InsertClothesController(GladeAppManager*, std::string, bool);
		
		bool clickClose(GdkEventAny*);
		
		void clotheschooser();
		void addclothes(std::string *, std::string *, std::string *);

};

class ViewClosetController: public ViewController {

	private:
		Gtk::Box* tops_container;
		Gtk::Box* bottoms_container;
		Gtk::Box* shoes_container;
		
		std::map<std::string, GalleryWidget*> hmap_tops;
		std::map<std::string, GalleryWidget*> hmap_bottoms;
		std::map<std::string, GalleryWidget*> hmap_shoes;
	public:
		ViewClosetController(GladeAppManager*, std::string, bool);
		
		bool clickClose(GdkEventAny*);

		void addTopsGallery(Gallery*);
		void addBottomsGallery(Gallery*);
		void addShoesGallery(Gallery*);
	
		void topsrefresh();
		void bottomsrefresh();
		void shoesrefresh();
};

class GenOutfitController: public ViewController {
	public:
		GenOutfitController(GladeAppManager*, std::string, bool);
		
		void generateoutfit();
		void postoutfit();
		void postoutfitsurls();
		bool clickClose(GdkEventAny*);
		
};

#endif
