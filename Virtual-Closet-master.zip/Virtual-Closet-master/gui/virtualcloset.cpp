#ifndef VIRTUALCLOSET
#define VIRTUALCLOSET

#include "virtualcloset.h"
#include <gtk/gtk.h>
#include <gtkmm.h>
#include <iostream>

//=============================================== Login ========================================================
//==============================================================================================================
LoginController::LoginController(GladeAppManager* gapManager, std::string windowName, bool isTopLevel):ViewController(gapManager, windowName, isTopLevel){
	// Sets the size and position of the window
	window->set_title("IntroWindow");
	window->set_default_size(600, 900);	
	window->set_position(Gtk::WIN_POS_CENTER_ALWAYS);

	// Assigns login() as handler for clicking on the login button
	Gtk::Button* loginButton = Gtk::manage(new Gtk::Button("LoginButton"));
  	builder->get_widget("LoginButton", loginButton);
	
	Gtk::Image loginimage("fbloginbutton.png");
	loginButton->set_image(loginimage);

	loginButton->signal_clicked().connect( sigc::mem_fun(*this, &LoginController::login) );

	FbManager* mgr = FB::getManager();
	mgr->addConnectionListener(this);
	
}

void LoginController::login()
{	
	FbManager* mgr = FB::getManager();
	mgr->login(gapManager->getGtkApplication()->get_id());
}

void LoginController::loginSuccess()
{	
	gapManager->showView("OptionsWindow");
}
	
bool LoginController::clickClose(GdkEventAny* evt){
	// Exit the GUI
	gapManager->exit();
	return false;
}


//============================================= Options ========================================================
//==============================================================================================================
OptionsController::OptionsController(GladeAppManager* gapManager, std::string windowName, bool isTopLevel):ViewController(gapManager, windowName, isTopLevel){

	// Sets the size and position of the window
	window->set_title("OptionsWindow");
	window->set_default_size(900, 600);	
	window->set_position(Gtk::WIN_POS_CENTER_ALWAYS);
	
	//=================
	//option 1 button
	Gtk::Button* o1Button = nullptr;
	builder->get_widget("InsertClothes", o1Button);
	o1Button->signal_clicked().connect( sigc::mem_fun(*this, &OptionsController::insertclothes) );
	
	//==================	
	//option 2 button
	Gtk::Button* o2Button = nullptr;
  	builder->get_widget("ViewCloset", o2Button);
	o2Button->signal_clicked().connect( sigc::mem_fun(*this, &OptionsController::viewcloset) );

	//==================
	//option 3 button
	Gtk::Button* o3Button = nullptr;
  	builder->get_widget("GenerateOutfit", o3Button);
	o3Button->signal_clicked().connect( sigc::mem_fun(*this, &OptionsController::genoutfit) );

}
void OptionsController::insertclothes(){
	gapManager->showView("InsertClothesWindow");
}
void OptionsController::viewcloset(){

	gapManager->showView("ViewClosetWindow");
}
void OptionsController::genoutfit(){

	gapManager->showView("GenOutfitWindow");
}
bool OptionsController::clickClose(GdkEventAny* evt){

	gapManager->showView("IntroWindow");
	return false;
}


//=========================================== InsertClothes ====================================================
//==============================================================================================================
InsertClothesController::InsertClothesController(GladeAppManager* gapManager, std::string windowName, bool isTopLevel):ViewController(gapManager, windowName, isTopLevel){
// Sets the size and position of the window
	window->set_title("InsertClothesWindow");
	window->set_default_size(-1, 600);	
	window->set_position(Gtk::WIN_POS_CENTER_ALWAYS);
	
	Gtk::Button* clothesChooserButton = nullptr;
	builder->get_widget("btn_clotheschooser", clothesChooserButton);
	
	clothesChooserButton->signal_clicked().connect( sigc::mem_fun(*this, &InsertClothesController::clotheschooser) );

}

bool InsertClothesController::clickClose(GdkEventAny* evt){
	// Switch the view to the login window when the x button is clicked
	gapManager->showView("OptionsWindow");
	return false;
}

void InsertClothesController::clotheschooser(){

	Gtk::CheckButton * tc_Button = nullptr;
	builder->get_widget("TopCheckButton", tc_Button);
		
	Gtk::CheckButton * bc_Button = nullptr;
	builder->get_widget("BottomsCheckButton", bc_Button);

	Gtk::CheckButton * sc_Button = nullptr;
	builder->get_widget("ShoesCheckButton", sc_Button);

	Gtk::CheckButton * ac_Button = nullptr;
	builder->get_widget("AthleticCheckButton", ac_Button);
		
	Gtk::CheckButton * ec_Button = nullptr;
	builder->get_widget("EverydayCheckButton", ec_Button);

	Gtk::CheckButton * fc_Button = nullptr;
	builder->get_widget("FancyCheckButton", fc_Button);
	
	//FileChooserDialog for when an image is chosen
	//Gets filename
	Gtk::FileChooserDialog dialog("Choose Image", Gtk::FILE_CHOOSER_ACTION_OPEN);
	dialog.set_transient_for(*window);
	dialog.add_button(Gtk::Stock::CANCEL, Gtk::RESPONSE_CANCEL);
	dialog.add_button(Gtk::Stock::SAVE, Gtk::RESPONSE_OK);

	int result = dialog.run();
   	std::string filename;
	std::string category;
	std::string style;	
   	
	switch(result)
   	{
  	  case(Gtk::RESPONSE_OK):
  	 {
		filename = dialog.get_filename();
		//assigns option of checked boxes to appropriate strings
		if(tc_Button->get_active() == true) {category = "top";}
		if(bc_Button->get_active() == true) {category = "bottom";}
		if(sc_Button->get_active() == true) {category = "shoes";}
		if(ac_Button->get_active() == true) {style = "athletic";}
		if(ec_Button->get_active() == true) {style = "everyday";}
		if(fc_Button->get_active() == true) {style = "fancy";}
		
		//passes strings to function
		addclothes(&filename, &category, &style);
  	     	break;
 	 }
  	 case(Gtk::RESPONSE_CANCEL):
  	 {
  	      std::cout << "Canceled..." << std::endl;
 	       break;

 	 }
  	 default:
 	 {
  	      std::cout << "Whoops..." << std::endl;
  	      break;
   	 }
  	}
	
	

}

void InsertClothesController::addclothes(std::string* filen, std::string* categn, std::string* stylen){
	
	//new strings	
	std::string filename = *filen; //filename
	std::string category = *categn;
	std::string style = *stylen;

	//For integration
	/*creates new object from class in DB
	if(category == everday) 
	{	
		if(style == top)
		{
		Top x = new Top();
		}
		if(style == bottom)
		{
		Bottom x = new Bottom();
		}
		if(style == shoes)
		{
		Shoes x = new Shoes();
		}
	} 
	if(category == athletic) 
	{
		if(style == top)
		{
		Top x = new Top();
		}
		if(style == bottom)
		{
		Bottom x = new Bottom();
		}
		if(style == shoes)
		{
		Shoes x = new Shoes();
		}
	} 
	if(category == fancy) 
	{
		if(style == top)
		{
		Top x = new Top();
		}
		if(style == bottom)
		{
		Bottom x = new Bottom();
		}
		if(style == shoes)
		{
		Shoes x = new Shoes();
		}
	}
	*/
	

}
//============================================ ViewCloset ======================================================
//==============================================================================================================
ViewClosetController::ViewClosetController(GladeAppManager* gapManager, std::string windowName, bool isTopLevel):ViewController(gapManager, windowName, isTopLevel){

	// Sets the size and position of the window
	window->set_title("ViewClosetWindow");
	window->set_default_size(900, 600);	
	window->set_position(Gtk::WIN_POS_CENTER_ALWAYS);
	
	tops_container = nullptr;
	builder->get_widget("tops_box", tops_container);

	bottoms_container = nullptr;
	builder->get_widget("bottoms_box", bottoms_container);
	
	shoes_container = nullptr;
	builder->get_widget("shoes_box", shoes_container);

	
	
	Gtk::Button* tops_Refresh = nullptr;
	builder->get_widget("topsRefresh", tops_Refresh);
	tops_Refresh->signal_clicked().connect( sigc::mem_fun(*this, &ViewClosetController::topsrefresh) );

	Gtk::Button* bottoms_Refresh = nullptr;
	builder->get_widget("bottomsRefresh", bottoms_Refresh);
	bottoms_Refresh->signal_clicked().connect( sigc::mem_fun(*this, &ViewClosetController::bottomsrefresh) );

	Gtk::Button* shoes_Refresh = nullptr;
	builder->get_widget("shoesRefresh", shoes_Refresh);
	shoes_Refresh->signal_clicked().connect( sigc::mem_fun(*this, &ViewClosetController::shoesrefresh) );

}
void ViewClosetController::topsrefresh()
{
	//something like this
	//needs "gallery loader" from DB
	/*std::vector<Gallery*> gallerys = GalleryLoader::getGallery();
	for loop outputting posts
	{
		addTopsGallery(p);
	}
	*/

}

void ViewClosetController::bottomsrefresh()
{
	//something like this
	//needs "gallery loader" from DB
	/*std::vector<Gallery*> gallerys = GalleryLoader::getGallery();
	for loop outputting posts
	{
		addBottomsGallery(p);
	}
	*/
}

void ViewClosetController::shoesrefresh()
{
	//something like this
	//needs "gallery loader" from DB
	/*std::vector<Gallery*> gallerys = GalleryLoader::getGallery();
	for loop outputting posts
	{
		addShoesGallery(p);
	}
	*/
}

void ViewClosetController::addTopsGallery(Gallery * gallery)
{
	/* NEEDED TO BE COMPLETED
		if(gallerys.count(gallert->getImage())==0
		{
			GalleryWidget* p = Gtk::manage(new GalleryWidget(post));
			gallerys[gallery->getImage() = p;
			img_container->add(*p);	
		}
	*/
}

void ViewClosetController::addBottomsGallery(Gallery * gallery)
{
	
	/*NEEDED TO BE COMPLETED
		if(gallerys.count(gallert->getImage())==0
		{
			GalleryWidget* p = Gtk::manage(new GalleryWidget(post));
			gallerys[gallery->getImage() = p;
			img_container->add(*p);	
		}
	*/
}

void ViewClosetController::addShoesGallery(Gallery * gallery)
{
	
	/*NEEDED TO BE COMPLETED
		if(gallerys.count(gallert->getImage())==0
		{
			GalleryWidget* p = Gtk::manage(new GalleryWidget(post));
			gallerys[gallery->getImage() = p;
			img_container->add(*p);	
		}
	*/
}

bool ViewClosetController::clickClose(GdkEventAny* evt){
	// Switch the view to the login window when the x button is clicked
	gapManager->showView("OptionsWindow");
	return false;
}

GalleryWidget::GalleryWidget(Gallery* p)
{
	post = p;
	//creates new hBox to add widgets
	img_container = new Gtk::Hbox();
	pack_start(*img_container, true, true);

	if(!p->getImage().empty())
	{
		image = new Gtk::Image(p->getImage());
		image->set_halign(Gtk::ALIGN_START);
		pack_start(*image, true, true, 25);
			
	}
		show_all();
}
std::string GalleryWidget::getImage()
{
	//returns image
	return "";
}
//=============================================GenOutfit========================================================
//==============================================================================================================
GenOutfitController::GenOutfitController(GladeAppManager* gapManager, std::string windowName, bool isTopLevel):ViewController(gapManager, windowName, isTopLevel){

	// Sets the size and position of the window
	window->set_title("GenOutfitWindow");
	window->set_default_size(900, 600);	
	window->set_position(Gtk::WIN_POS_CENTER_ALWAYS);

	outfit_container = nullptr;
	builder->get_widget("outfit_box", outfit_container);


	std::string url;
	std::string post;	
	
	Gtk::Button * genOutfit = nullptr;
	builder->get_widget("btn_gen", genOutfit);
	genOutfit->signal_clicked().connect( sigc::mem_fun(*this, &GenOutfitController::generateoutfit) );
	
	Gtk::Button * postOutfit = nullptr;
	builder->get_widget("btn_post", postOutfit);
	
	//Creating Entry widgets
	//used to get img user inputted URL and FB Posts 
	Gtk::Entry * urlEntry = nullptr;
	builder->get_widget("urlText", urlEntry);

	Gtk::Entry * postEntry = nullptr;
	builder->get_widget("postText", postEntry);
	
	//assigns user text entry to strings
	url = urlEntry->get_text();
	post = postEntry->get_text();
	
	postoutfiturls(&url,&post);

	postOutfit->signal_clicked().connect( sigc::mem_fun*this, GenOutfitController::postoutfit) );	
	
}

void GenOutfitController::generateoutfit()
{
	//Should call from db to get three images
	//that create an outfit and is shown on the GUI.
	//using the postloader
	
	//something like this
	/*std::vector<Gallery*> posts = GalleryLoader::getGallery();
	for loop outputting posts
	{
		addgeneratedoutfit(p);
	}
	*/
	
}
void GenOutfitController::addgeneratedoutfit()
{
	/*Should be called when generated outfit is pressed
		if(gallerys.count(post->getImage()))==0
		{
			GalleryWidget* p = Gtk::manage(new GalleryWidget(gallery));
			gallerys[gallery->getImage() = p;
			outfit_container->add(*p);
		}
	*/
}
void GenOutfitController::postoutfit()
{
	//send to api
	//need api class in order to create object for url and post
}
bool GenOutfitController::clickClose(GdkEventAny* evt){
	// Switch the view to the login window when the x button is clicked
	gapManager->showView("OptionsWindow");
	return false;
}
GenerateOutfitWidget::GenerateOutfitWidget(GenerateOutfit* p)
{
	post = p;
	//creates new HBox to inser image widget
	image = new Gtk::Image(imageLoc);
	outfit_container = new Gtk::Hbox();

	outfit_container->pack_start(*image, true, true, 25);
	
	show_all();
}
std::string GalleryWidget::getImage()
{
	//returns image
	return "";
}




#endif
