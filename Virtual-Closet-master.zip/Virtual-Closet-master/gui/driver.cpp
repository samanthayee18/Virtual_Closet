
#include "virtualcloset.h"
#include <iostream>

int main(){
	// Create the Glade application manager
	GladeAppManager gapManager("virtualclosetv3.glade"); 
	//========================================================
	LoginController lc(&gapManager, "IntroWindow", true); 
	OptionsController oc(&gapManager, "OptionsWindow", false);
	InsertClothesController ic(&gapManager, "InsertClothesWindow", false);
	ViewClosetController vc(&gapManager, "ViewClosetWindow", false);
	GenOutfitController gc(&gapManager, "GenOutfitWindow", false);

	// Start the GUI
	gapManager.start();

	// Start will run while the GUI is displayed. Statements after the call to start will only run after the
	// GUI closes

}

