
#include <sqlite3.h>
#include <string>

int main()
{
 sqlite3* db;
 sqlite3_open("test.db", &db);
 char* sql = "CREATE TABLE Tops ( Tops_ID INT PRIMARY KEY, Type_VNeck char NOT NULL, Type_BottonUp char NOT NULL, Type_Tank char NOT NULL, Type_Crew char NOT NULL, Type_TurtleNeck NOT NULL, Type_Sweatshirts NOT NULL);";
 sqlite3_exec(db, sql, NULL, 0, NULL);

 sql = "INSERT INTO Tops(Tops_ID, Type_VNeck) VALUES (1, \"Hello World \");";

 sqlite3_exec(db, sql, NULL, 0, NULL);

 sqlite3_close(db); 

 return 0;
}
