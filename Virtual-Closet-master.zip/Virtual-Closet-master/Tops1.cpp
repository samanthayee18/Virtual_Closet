#include <iostream>
#include <string>
#include <sqlite3.h>
#include <string>

using namespace std;

class Tops
{
public:
        char *shortSleeves[100];
        char *longSleeves[100];

/*class ShortSleeevs: public Tops
{
        struct shortSleeve
        {
                char VNeck[30];
                char CrewNeck[30];
                char TankTop[30];
                char BottomU[30];;

                shortSleeve *next;
        };

public:*/
        Tops();
        ~Tops();
        char* getData();
	void save();	

        //void setVNeck(const char *);
        //void setCrewNeck(string);
        //void setTankTop(string);
        //void setBottomUp(string);

        //void getShirtType(string);

private:
        //shortSleeve *head;
};

class LongSleeves : public Tops
{
	LongSleeves();
	~LongSleeves();

	void getShirtType();

private:
	string VNeck;
	string CrewNeck;
	string BottomUp;
};

char* Tops::getData()
{
 char* shortSleeves = new char[100];
 cout << "Please enter a short sleeve option\n";
 cin.getline(shortSleeves, 100);

 return shortSleeves;
}

void Tops::save()
{
 char* input = getData();
 sqlite3* db;
 sqlite3_open("test.db", &db);
 char* sql = "CREATE TABLE Tops ( Tops_ID INT PRIMARY KEY, Type_VNeck char NOT NULL, Type_BottonUp char NOT NULL, Type_Tank char NOT NULL, Type_Crew char NOT NULL, Type_TurtleNeck NOT NULL, Type_Sweatshirts NOT NULL);";
 sqlite3_exec(db, sql, NULL, 0, NULL);

 sql = "INSERT INTO Tops(Tops_ID, Type_VNeck) VALUES (1, \"" + input +" \");";

 sqlite3_exec(db, sql, NULL, 0, NULL);

 sqlite3_close(db);
}

int main()
{
 Tops test;
 test.save();

 return 0;
}
