#include <iostream>
#include "Tops.h"
#include <string>

ShortSleeevs::ShortSleeevs()
{
	head = NULL;
};

ShortSleeevs::~ShortSleeevs() {};

void ShortSleeevs::setVNeck(const char *vneck)
{
	char temp[30];
	strncpy_s(temp, vneck, 29);
	strncpy_s(ShortSleeevs::head.VNeck, temp, 29);
}



void ShortSleeevs::getShirtType(string shirtType)
{

}
