#endif // !TOPS1_H#pragma once
#ifndef TOPS1_H
#define TOPS1_H
#include <iostream>
#include <string>
using namespace std;

class Tops
{
public:
	char shortSleeves;
	char longSleeves;
};

class ShortSleeevs: public Tops
{
	struct shortSleeve
	{
		char VNeck[30];
		char CrewNeck;
		char TankTop;
		char BottomUp;

		shortSleeve *next;
	};

public:
	ShortSleeevs();
	~ShortSleeevs();
	
	void setVNeck(const char *);
	void setCrewNeck(string);
	void setTankTop(string);
	void setBottomUp(string);

	void getShirtType(string);

private:
	shortSleeve *head;
};

class LongSleeves : public Tops
{
	LongSleeves();
	~LongSleeves();

	void getShirtType();

private:
	string VNeck;
	string CrewNeck;
	string BottomUp;
};
#endif // !TOPS1_H
