#include <iostream>
#include <sqlite3.h>
#include <string>
#include <cstring>
#include "db.h"
#include <vector>
using namespace std;


class Bottoms
{
public:
char* everyDay[100];
char* athletic[100];
char* fancy[100]; 

std::string ID;
std::string BottomType;
bool remembered;

std:: vector<Bottoms*> getData();
int callback(void*, std::string, std::string);
bool isRemembered();
void setRemembered(bool);
std::string getBottomType();

Bottoms();
Bottoms(std::string ID, std::string BottomType);
~Bottoms();

void save();

private:

};

std::string Bottoms::getBottomType()
{
char BottomType;
cout<<"a. Everyday\n";
cout<<"b. Athletic\n";
cout<<"c. Fancy\n";
cin>> BottomType;

switch(BottomType)
{
case 'a' : return "Everyday"; break;
case 'b' : return "Athletic"; break;
case 'c' : return "Fancy"; break;
}
}

void Bottoms::save()
{
std::string input = getBottomType();
sqlite3* db; //=DB::getConnections();
sqlite3_open("test.db",&db);
std::string sql="CREATE TABLE Bottoms (Bottoms_ID INT PRIMARY KEY, Type_Everyday char NOT NULL, Type_Athletic char NOT NULL, Type_Fancy);";
sqlite3_exec(db, sql.c_str(), NULL,0,NULL);

sql="INSERT INTO Tops (Tops_ID, Type_Everyday) VALUES (1,\""+input+"\");";

char* err;

sqlite3_exec(db, sql.c_str(), NULL, 0, &err);
if(err!=NULL)
{
cout<<err<<endl<<std::flush;
}

sqlite3_close(db);
}

Bottoms:: Bottoms(){}
Bottoms:: ~Bottoms(){}
Bottoms::Bottoms(std::string ID, std::string BottomType)

{
this->ID=ID;
this->BottomType=BottomType;
}

std::vector<Bottoms*> Bottoms::getData()

{
std::vector<Bottoms*>* bottom = new std::vector<Bottoms*>;
sqlite3* db;// DB::getConnection();
sqlite3_open("test.db", &db);
std::string sql="SELECT Bottoms_ID, Type_Everyday From Bottoms";
char*err;
sqlite3_exec(db,sql.c_str(),0/*Bottoms::callback*/, bottom, &err);
if(err!=NULL)
{
cout<<err<<endl<<std::flush;
}
sqlite3_close(db);
return *bottom;
}

int Bottoms::callback(void *data, std::string ID, std::string BottomType)
{
std::vector<Bottoms*>* bottom = (std::vector<Bottoms*>*)data;
Bottoms*b= new Bottoms(ID,BottomType);
b->setRemembered(true);
(*bottom).push_back(b);
return 0;
}

bool Bottoms::isRemembered()
{
return remembered;
}

void Bottoms::setRemembered(bool remembered)
{
this->remembered = remembered;
}

int main()
{

Bottoms test;
test.save();

return 0;
}

