#include <cpprest/http_client.h>
#include <cpprest/uri.h>  
#include "oauth2.h"
#include <iostream>
#include "fbapi.h"

using namespace web; 
using namespace web::http;
using namespace web::http::client; 

int main(){
	FB::configure("1486339698110826", "user_posts");
	FbManager* mgr = FB::getManager();
	mgr->getPosts();

	return 0;
}
