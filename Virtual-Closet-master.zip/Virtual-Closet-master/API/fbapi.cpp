#include "fbapi.h"

/* Default variable values */
FbManager* FB::fbManager = NULL;
std::string FB::clientId = "xxxx";
std::string FB::scope = "user_posts";

/* Specifies the client ID and scope used by the FB manager
	 A new connection will be created whenever the manager is reconfigured	
*/
void FB::configure(std::string clientId, std::string scope){
	FB::clientId = clientId;
	FB::scope = scope;
	if(FB::fbManager!=NULL)
		delete fbManager;
	else
		getManager();
}

/* Retrieves the current FB manager. A new manager will be created
   if it does not yet exist.
*/
FbManager* FB::getManager(){
	if(FB::fbManager == NULL){
		fbManager = new FbManager(clientId, scope);
		fbManager->login();
	}
	return fbManager;
}

/* Creates an FB manager using the given client ID and scope */
FbManager::FbManager(std::string clientId, std::string scope){
	this->clientId = clientId;
	this->scope = scope;
	apiVersion = "v2.10";
}

/* Remove unicode sequence from json string */
std::string FbManager::clean_json(std::string json){
   std::regex pattern("\\\\u[a-fA-F0-9]{4}");
   return std::regex_replace(json, pattern, " ");
}

/* Method called after the user successfully logs in to Facebook */
void FbManager::authorize(std::string param, std::string value){
	accessToken = value;
}

/* Retrieves the access token generated after a successful login */
std::string FbManager::getAccessToken(){
	if(accessToken.empty())
		throw UnavailableAccessTokenException();
	else
		return accessToken;
}

/* Initiates the login proces using the OAuth2 protocol */
void FbManager::login(){
	uri_builder login("https://www.facebook.com/" + apiVersion + "/dialog/oauth");
	login.append_query("client_id", clientId);
	login.append_query("response_type", "token");
	login.append_query("scope", scope);
	login.append_query("redirect_uri", "https://www.facebook.com/connect/login_success.html");
	OAuth2 auth(login.to_string(), "access_token");
	auth.init(this);
}

/*  posts photo to the /me/photos Facebook endpoint */
void FbManager::getPosts(){
	http_client client(U("https://graph.facebook.com/v2.10"));
uri_builder builder(U("/me/photos"));
builder.append_query(U("access_token"),accessToken);
builder.append_query(U("caption"),"Virtual-Closet");
builder.append_query(U("url"), "https://i.imgur.com/hCvMth9.jpg");
pplx::task<void> task = client.request(methods::POST, builder.to_string()).then([&] (http_response response){
	std::cout << response.extract_string().get();
});
task.wait();
}
